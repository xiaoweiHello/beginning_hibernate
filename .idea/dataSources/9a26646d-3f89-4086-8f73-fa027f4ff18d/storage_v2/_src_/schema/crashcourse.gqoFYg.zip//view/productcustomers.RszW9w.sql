CREATE VIEW productcustomers AS
  SELECT
    `crashcourse`.`customers`.`cust_name`    AS `cust_name`,
    `crashcourse`.`customers`.`cust_contact` AS `cust_contact`,
    `crashcourse`.`orderitems`.`prod_id`     AS `prod_id`
  FROM `crashcourse`.`customers`
    JOIN `crashcourse`.`orders`
    JOIN `crashcourse`.`orderitems`
  WHERE ((`crashcourse`.`customers`.`cust_id` = `crashcourse`.`orders`.`cust_id`) AND
         (`crashcourse`.`orderitems`.`order_num` = `crashcourse`.`orders`.`order_num`));

